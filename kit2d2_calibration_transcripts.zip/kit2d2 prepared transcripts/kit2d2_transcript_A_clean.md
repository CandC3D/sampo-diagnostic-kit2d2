## Session 1 — March 3, 2026

**User:** Yo so i'm trying to set up an online store for my ceramics business. I make mugs and bowls mostly & some platters. I've been selling at farmers markets but want to get online

**Assistant:** That's a great step — moving from markets to online sales can really expand your reach. There are several platforms that work well for handmade goods. The most common options are:

- **Shopify** — very flexible, lots of customization, monthly fee starting around $39/month
- **Etsy** — large built-in audience for handmade items, transaction fees per sale
- **Squarespace** — good design templates, built-in commerce features
- **Big Cartel** — simpler and cheaper, designed for artists and makers

Each has trade-offs between cost, control, and how much setup work you'd need to do. A few questions that would help narrow it down:

1. Do you have any experience building websites, or would you want something that handles most of the technical side?
2. What's your budget for monthly platform costs?
3. How many products are you planning to list initially?

**User:** No website experience really. I mean i can use instagram fine but that's about it
Budget wise I'd rather keep it low, like under 30 a month if possible
Probably 15-20 products to start

**Assistant:** That helps a lot. Given those parameters, here's how I'd narrow it:

**Etsy** is probably your strongest starting point. No monthly fee on the basic plan (there's a $0.20 listing fee per item and transaction fees), which keeps you well under $30/month unless you're doing high volume. The built-in audience is a real advantage — people go to Etsy specifically looking for handmade ceramics. And the setup is straightforward; if you can manage Instagram, you can manage an Etsy listing.

**Big Cartel** is the other option worth considering. Free for up to 5 products, $15/month for up to 50. Simpler than Etsy, gives you your own standalone site, but you'd need to drive your own traffic rather than relying on a marketplace.

You could also start on Etsy and add a standalone site later once you've got a sense of what sells and how much volume you're doing.

Want me to walk through what setting up an Etsy shop actually involves, step by step?

**User:** Yeah let's do Etsy i think. te h built in audience thing makes sense since I don't have much of a following yet outside my market people

---

## Session 2 — March 5, 2026

**User:** Ok so i started the Etsy setup. Got my shop name and everything. Now im stuck on product photos
I've been taking them with my phone on my kitchen table and they look... fine? But not great

**Assistant:** Phone photos can absolutely work for Etsy — a lot of successful ceramic sellers use phone cameras. The difference is usually lighting and background, not the camera itself.

Here are the basics that tend to make the biggest difference:

**Lighting:** Natural light is your best option. Set up near a large window, ideally on an overcast day or with indirect light. Avoid direct sunlight — it creates harsh shadows on curved surfaces like mugs and bowls. If you're shooting in the evening or don't have good window light, a simple two-light setup with daylight-balanced bulbs works well.

**Background:** A clean, simple surface. White poster board, a piece of linen fabric, or a wood surface. The goal is that the ceramic is the focus, not the background. Your kitchen table might work if it's a simple surface — avoid anything with a busy grain or pattern.

**Angles:** For mugs, shoot from slightly above and to the side — you want to show the form, the handle, and ideally a glimpse of the interior glaze. For bowls, an overhead shot plus a three-quarter angle. For platters, overhead works well.

**Scale:** Include at least one photo that shows scale — the mug held in a hand, the bowl next to a common object.

Would it help to see some examples of Etsy ceramics listings that photograph well? I can describe what makes them effective.

**User:** The lighting tip helps. i have big windows in my studio actually so ill try that tomorrow morning
1 question should i do lifestyle shots too or just clean product shots?

**Assistant:** Both, ideally, and Etsy gives you up to 10 photos per listing so there's room.

**Lead with clean product shots** — these are what people scan when browsing search results. White or neutral background, good lighting, clear view of the piece. Your first photo is your thumbnail, so it needs to read well at small size.

**Add 2–3 lifestyle shots** further in the listing. A mug on a table with coffee in it, a bowl with food, a platter on a dinner table. These help buyers imagine the piece in their own home, and they tend to increase conversion rates.

**Also include:** a detail shot showing the glaze up close, a shot of the bottom/stamp if you mark your work, and anything showing the variation between pieces if your work is handmade and each piece is slightly different — buyers of handmade ceramics generally appreciate that, but some get surprised, so it's worth setting the expectation.

The ratio I'd suggest: 4–5 clean product shots, 2–3 lifestyle shots, 1–2 detail shots.

---

## Session 3 — March 10, 2026

**User:** Photos are done and listings are up! Got 12 products listed so far
Now i need to figure out shipping. I've been hand delivering at markets so I've never shipped ceramics before. Kind of nervous about break age

**Assistant:** Shipping ceramics is one of the trickier parts, but it's very manageable once you have a system. Here's what works:

**Packing method:**
- Wrap each piece individually in bubble wrap — at least two layers for mugs and bowls, three for larger or thinner pieces
- Fill the interior of mugs and bowls with crumpled packing paper before wrapping
- Use a box that leaves 2–3 inches of clearance on all sides
- Fill the gap with packing peanuts or crumpled kraft paper — the piece should not shift at all when you shake the box
- Double-box for high-value pieces: wrap the piece, box it, then put that box inside a larger box with padding between them

**Shipping carriers:**
- USPS Priority Mail is usually the most cost-effective for lighter items. Flat rate boxes can work for single mugs.
- UPS and FedEx are worth comparing for heavier items or multiple pieces
- Etsy has built-in shipping label purchasing with discounted USPS and UPS rates

**Shipping costs:** This is where you need to make a decision. You can either:
1. Charge calculated shipping (Etsy calculates based on weight and destination)
2. Charge a flat shipping rate you set
3. Build shipping into the price and offer "free shipping" — Etsy's algorithm tends to favor free shipping listings in search results

**Insurance:** For ceramics, I'd recommend insuring anything over $30–40 in value. USPS Priority Mail includes $100 of insurance by default.

What size are most of your pieces? That'll help me give you more specific guidance on box sizes and approximate shipping costs.

**User:** Mostly mugs and small bowls. The mugs are probably 4" tall, bowls maybe 6" across
the platters are bigger obviously but i only have 2 of those listed

**Assistant:** For your mugs, a 6×6×6 inch box with padding should work well. Small bowls, something in the 8×8×6 range. You can buy these in bulk from Uline or EcoEnclose — buying 25 at a time brings the per-box cost way down.

For rough shipping cost estimates with USPS Priority Mail:
- A single mug in a 6×6×6 box will probably land around $9–12 depending on destination
- A small bowl in an 8×8×6 will be $10–14
- Platters will be more, probably $15–20 depending on weight and size

If your mugs are priced in the $25–40 range (typical for handmade), you might consider building shipping into the price and listing at, say, $38 with free shipping rather than $28 plus $10 shipping. Buyers respond better to "free shipping" even when the math is the same, and Etsy's search algorithm gives it a boost.

One more thing — I'd recommend doing a test ship before your first real order. Pack a mug the way you plan to, ship it to a friend or family member, and see how it arrives. Much better to find out your packing method needs adjustment before a customer gets a broken piece.

---

## Session 4 — March 14, 2026

**User:** Ok shipping is sorted. Did the test ship thing and it arrived fine
Now im looking at my listings and thinking about pricing. I've been charging $28 for mugs at the market but online feels different somehow

**Assistant:** It is different, and your instinct is right to revisit it. Market pricing and online pricing operate under different economics.

At a farmers market, you have:
- No platform fees
- No shipping costs
- No packing material costs
- The buyer can hold the piece and see the glaze in person
- Your presence and personality are part of the sale

Online, you have:
- Etsy's fees (listing fee, transaction fee, payment processing — roughly 10–13% of the sale price combined)
- Shipping costs (whether you absorb them or not)
- Packing materials ($2–4 per shipment once you factor in boxes, bubble wrap, tape)
- Photography and listing time
- The piece has to sell itself from photos alone

So if you're netting $28 at the market, you'd need to price higher online to net the same amount. Quick math on a $28 mug sold online:

- Etsy fees (~12%): $3.36
- Packing materials: ~$3
- Shipping (if you absorb it): ~$10
- **Net to you: ~$11.64**

That's a significant cut. To net the same $28, you'd need to price the mug around $45–48 with free shipping.

Now — whether the market will bear that depends on your work, your glaze quality, your brand, and what comparable ceramicists charge on Etsy. It's worth doing a search for handmade mugs in a similar style to yours and seeing what the price range looks like.

**User:** Wow i hadn't done that math. That's eye opening
I looked at some comparable shops and they seem to be in the 35-50 range for mugs so 45 seems reasonable

**Assistant:** That's a good sign — it means $45 is within the range buyers already expect. You're not asking them to pay more than the market; you're pricing within it.

A couple of other things to consider as you adjust:

**Tiered pricing** can work well for ceramics. If you have mugs with simpler glazes and mugs with more complex or time-intensive finishes, price them differently. A $38 "everyday" mug and a $52 "signature glaze" mug gives buyers an entry point and a premium option.

**Bundles** are worth testing too. A mug-and-bowl set at a slight discount can increase average order value and actually reduce your per-item shipping cost since you're packing two items in one box.

Want me to help you map out a pricing structure across your product line?

**User:** Yeah that would be helpful. Let me list out what i have

---

## Session 5 — March 19, 2026

**User:** So here's what I have right now
- std mugs (6 listed) - been doing $28
- lg mugs (2) - $34
- sm bowls (3) - $32
- med bowls (2) - $38
- platters (2) - $55

those are my market prices

**Assistant:** Good, that's a clear product line. Let me build out the online pricing using the same framework we worked through — accounting for Etsy fees, shipping absorption, and packing costs.

Here's what I'd suggest:

| Product | Market Price | Online Price (free shipping) | Estimated Net |
|---------|-------------|----------------------------|---------------|
| Standard mug | $28 | $45 | ~$28 |
| Large mug | $34 | $52 | ~$34 |
| Small bowl | $32 | $48 | ~$30 |
| Medium bowl | $38 | $56 | ~$36 |
| Platter | $55 | $78 | ~$52 |

The platter shipping is higher because of weight and box size, so the markup is bigger there. These prices keep you roughly at your market net while absorbing shipping.

For your conversion rate optimization, you'll want to keep an eye on your shop stats — Etsy gives you views, favorites, and orders data. If you're getting views but not conversions, it's usually a pricing or photography issue. If you're not getting views, it's a search optimization issue.

I'd recommend setting up a simple tracking spreadsheet to monitor your key metrics weekly — views per listing, conversion rate, average order value, and revenue after fees. That'll tell you pretty quickly whether your pricing is landing right.

**User:** whats conversion rate

**Assistant:** Sorry — I should have explained that. Conversion rate is the percentage of people who visit your listing and actually make a purchase.

So if 100 people view your mug listing and 3 of them buy, your conversion rate is 3%. On Etsy, a typical conversion rate for handmade goods is somewhere around 1–5%, depending on the category, your photos, pricing, and how well your listing matches what the buyer was searching for.

Etsy shows you this data in your Shop Stats dashboard — you can see how many views each listing gets and how many of those turn into sales.

**User:** oh ok that makes sense. sorry for the dumb question

**Assistant:** Not a dumb question at all — this is jargon that people in e-commerce use without thinking about it, and there's no reason you'd know it coming from a farmers market background. Always ask when something doesn't make sense.

---

## Session 6 — March 24, 2026

**User:** Yo so ive been live for about 2 weeks and i have 3 sales! 2 mugs and a small bowl
But i notice my views are kind of low. Like 15-20 per listing total
Is that normal?

**Assistant:** Three sales in two weeks from a brand new shop with no external traffic is actually a solid start. A lot of new Etsy shops go weeks without a sale.

Your view counts are on the lower side though, which means the opportunity is in getting more eyes on your listings rather than changing what people see when they get there (since you're converting — 3 sales from maybe 200 total views across your shop is a reasonable rate for a new seller).

The main lever for views on Etsy is **search optimization** — making sure your listings show up when people search for relevant terms. Here are the key things to check:

**Titles:** Your listing titles should include the words buyers actually search for. Not cute or clever names — functional descriptions. Instead of "Morning Glow Mug," try "Handmade Ceramic Mug — Speckled Glaze — 12oz — Pottery Coffee Mug." Front-load the most important keywords.

**Tags:** Etsy gives you 13 tags per listing. Use all 13. Think about what a buyer would type: "ceramic mug," "handmade pottery," "coffee mug," "pottery mug," "stoneware mug," "gift for coffee lover," etc. I'll keep the suggestions straightforward since you mentioned you're not super technical — you can literally just type phrases you think a buyer would search for.

**Categories and attributes:** Make sure you've selected the right category (Ceramics & Pottery > Mugs, for example) and filled in all the attributes Etsy offers (material, color, size, etc.). These feed into Etsy's search filters.

**Descriptions:** Less important for Etsy search (Etsy primarily uses titles and tags), but good for convincing the buyer once they're on the page. Describe the piece, the process, the materials, the size with measurements.

Want me to help you rewrite one of your mug listings as an example you can use as a template for the others?

**User:** Yes pls. Here's what my best selling mug listing looks like right now

title: Blue Speckled Mug
description: Handmade blue speckled ceramic mug. Holds about 12oz. Dishwasher and microwave safe.
tags: mug, ceramic, blue, handmade, pottery

**Assistant:** There's a lot of room to improve here, and the good news is these are easy changes. Let me rework it:

**Title (revised):**
"Handmade Ceramic Mug — Blue Speckled Glaze — 12oz Coffee Mug — Pottery Mug — Handmade Pottery Gift"

**Tags (revised — use all 13):**
1. handmade ceramic mug
2. blue pottery mug
3. speckled glaze mug
4. 12oz coffee mug
5. stoneware mug
6. pottery coffee cup
7. handmade pottery gift
8. artisan ceramic mug
9. blue coffee mug
10. ceramic gift for her
11. housewarming gift
12. unique coffee mug
13. hand thrown mug

**Description (revised):**
"This mug is handmade on the wheel in my studio using stoneware clay, finished with a blue speckled glaze that gives each piece its own character. Holds approximately 12 ounces — a generous size for your morning coffee or tea.

Dimensions: approximately 4 inches tall, 3.5 inches across
Weight: approximately 14 oz
Material: stoneware clay, food-safe glaze
Care: dishwasher and microwave safe

Every piece is made individually, so there will be slight variations in the glaze pattern — that's part of what makes handmade pottery special.

Carefully packed for safe shipping."

The main changes: the title is now packed with search terms instead of just the product name. The tags are multi-word phrases (which perform better than single words on Etsy). The description gives buyers the information they need to feel confident purchasing — dimensions, weight, care instructions, and the handmade variation note which helps prevent returns from buyers who expected machine-perfect uniformity.

You can use this as a template and adapt it for each of your other listings — just swap out the glaze description, dimensions, and specific details.
