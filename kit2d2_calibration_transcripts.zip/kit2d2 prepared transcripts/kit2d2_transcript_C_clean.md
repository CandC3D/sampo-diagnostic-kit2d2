## Session 1 — February 18, 2026

**User:** I'm thinking about getting solar panels for my house and I have no idea where to start. Can you tell me the basics?

**Assistant:** Of course. Solar panel installation involves several moving parts, so let me lay out the big-picture steps first, and then we can dig into whichever ones you want to know more about.

**The basic sequence:**

1. **Figure out if your roof is a good candidate.** Not every roof works well for solar. The main factors are how much direct sunlight your roof gets, what direction it faces (south-facing is ideal in the Northern Hemisphere), how old your roof is (if it needs replacing in the next 5–10 years, you'd want to do that first), and whether there's significant shading from trees or other buildings.

2. **Understand the financials.** Solar panels are a significant upfront cost — typically $15,000–$30,000 before incentives for a residential system. But there are federal tax credits, state incentives, and sometimes local utility rebates that can reduce that significantly. There are also financing options including solar loans and leases.

3. **Get quotes from installers.** Most people get 3–5 quotes from different solar companies. The quotes will include system size, estimated production, equipment details, and total cost.

4. **Understand your electric bill.** Solar panels reduce or eliminate your electric bill, so the financial case depends heavily on how much you currently pay for electricity and how that's likely to change over time.

5. **Decide on ownership vs. leasing.** You can buy the system outright, finance it with a loan, or lease it. Each has different financial implications.

Before I go deeper on any of these — do you have a sense of where you are in this process? Have you had any conversations with solar companies yet, or is this purely the research stage?

**User:** Purely research at this point. I haven't talked to anyone yet. I want to understand what I'm looking at before anyone tries to sell me something

**Assistant:** That's a smart approach. Solar sales can be high-pressure, and it helps to know what questions to ask and what numbers to look for before you're sitting across from a salesperson.

Let me start with the first question, since it determines whether the rest of the process makes sense: is your roof a good candidate?

A few things I'd need to know to help you think through this:

1. What direction does your roof face? If you're not sure, you can check with a compass app on your phone or look at your house on Google Maps — north is up on the map.
2. Roughly how old is your roof?
3. Are there large trees or tall buildings nearby that shade your roof for significant parts of the day?
4. What state are you in? This matters for both sunlight hours and incentive programs.

**User:** The main part of the roof faces south, which sounds like that's good. The roof was replaced about 6 years ago so it's in good shape. There are some trees on the east side but the south-facing part gets full sun most of the day. I'm in North Carolina

**Assistant:** Those are strong fundamentals. South-facing roof, relatively new, minimal shading on the south side, and North Carolina has both good sun exposure and some state-level incentive programs. Let me break down what this means for you.

**Sunlight:** North Carolina averages about 4.5–5 peak sun hours per day, which is solidly above the national average. Your south-facing roof with minimal shading should capture most of that.

**Roof age:** With a 6-year-old roof, you've got at least 15–20 years of roof life remaining, which aligns well with the 25–30 year expected lifespan of modern solar panels. You wouldn't need to worry about removing panels to replace the roof anytime soon.

**Incentives in North Carolina:**
- The **federal Investment Tax Credit (ITC)** currently covers 30% of the total system cost. This is a dollar-for-dollar tax credit, not a deduction — so if your system costs $20,000, you'd get $6,000 off your federal taxes.
- North Carolina doesn't currently have a state tax credit for residential solar, but it does have **net metering** through Duke Energy and other utilities — meaning excess power your panels generate gets credited to your bill.
- Some utilities offer additional rebates, but these vary. It would help to know which utility company you have.

Do you know who your electric utility provider is, and roughly what you pay per month for electricity? Those two pieces will help me estimate the financial picture.

**User:** Duke Energy. My electric bill is about $140-160 a month, higher in summer with the air conditioning

---

## Session 2 — February 24, 2026

**User:** I've been reading about solar since we talked and I keep seeing terms I don't fully understand. What's the difference between kW and kWh? And what does "system size" actually mean when they say a "7kW system"

**Assistant:** Good questions — these terms get thrown around in solar marketing without much explanation.

**kW (kilowatt)** is a measure of power — how much electricity something can produce (or consume) at any given moment. When they say a "7kW system," they mean the panels can produce up to 7 kilowatts of electricity at peak output (full sun, ideal conditions).

**kWh (kilowatt-hour)** is a measure of energy — how much electricity is actually produced or consumed over time. If your 7kW system runs at full output for one hour, it produces 7 kWh. Your electric bill is measured in kWh — when Duke Energy charges you, they're charging per kWh consumed.

**System size** is the total rated capacity of all the panels combined, measured in kW. So a 7kW system might be twenty 350-watt panels (20 × 350W = 7,000W = 7kW). The system size determines how much electricity you can generate.

**The connection to your bill:** Your $140–160/month bill at Duke Energy's current rates probably means you're using roughly 1,000–1,200 kWh per month. A 7kW system in North Carolina with good south-facing exposure would typically produce about 850–1,000 kWh per month. So a 7kW system might cover 75–90% of your usage, and a slightly larger system (8–9kW) might cover all of it.

Does that help clarify? I want to make sure the units make sense before we get into the financial math, because everything from quotes to payback calculations uses these terms.

**User:** Yes that helps a lot. I kept seeing those numbers and not being sure what they actually measured.  So when I get a quote and it says 7kW I know that's the maximum output, and the actual production depends on how much sun I get

**Assistant:** Exactly right. The rated kW is the ceiling; actual production depends on sunlight, temperature (panels are slightly less efficient in extreme heat, ironically), shading, panel angle, and system losses from wiring and the inverter. That's why installers estimate annual production in kWh rather than just giving you the kW rating — the kWh estimate accounts for all those real-world factors.

One more term you'll encounter: **solar irradiance**, sometimes called "peak sun hours." This is the average amount of usable sunlight your location gets per day, measured in hours of equivalent peak sun. North Carolina's 4.5–5 peak sun hours is what drives the production estimate I gave you. An installer's quote should include a production estimate specific to your roof — they'll usually model it with satellite imagery of your house.

**User:** OK one more question. I keep seeing "microinverters vs string inverters" come up. Do I need to understand that or is it something the installer decides?

**Assistant:** It's worth understanding at a basic level, because it affects system cost, performance, and your options for future expansion. Let me explain both and then you can decide how much you want to get into it.

**String inverter:** All your panels are wired together in a "string" (like Christmas lights in series). The power from all panels flows to one central inverter box, usually mounted on the side of your house, which converts the DC power from the panels to AC power your house uses. This is the simpler, cheaper option. Downside: if one panel is shaded or underperforming, it can reduce output from the entire string.

**Microinverters:** Each panel gets its own small inverter mounted right behind it. Each panel operates independently. More expensive (typically $1,000–2,000 more for a residential system), but each panel performs at its maximum regardless of what's happening with the others. Also makes it easier to monitor each panel individually and to add more panels later.

For your situation — south-facing roof with minimal shading — a string inverter would likely work fine, since the main advantage of microinverters (shade tolerance) isn't a big factor for you. But if you think you might want to expand the system later, or if the east-side trees shade any panels in the morning, microinverters could be worth the extra cost.

This is something worth discussing with installers when you get quotes. You don't need to decide now — I just want you to know what the terms mean so you can ask informed questions.

**User:** That's helpful. I think I understand enough now to start looking at the financial side more seriously

---

## Session 3 — March 3, 2026

**User:** OK so I've been looking at the financial side. The 30% federal tax credit is the big one. But I'm retired and my income is mostly from Social Security and a pension and some investment income. Do I even have enough tax liability for the credit to matter?

**Assistant:** That's a critical question, and it's one that solar salespeople don't always address clearly. The federal Investment Tax Credit is a tax credit, not a refund — it reduces the taxes you owe, but only to zero. If your tax liability is less than the credit amount, you can't get the excess back as a refund.

However — and this is important — the ITC can be carried forward. If you can't use the full credit in the year you install the panels, you can apply the remainder to future tax years. So even with a lower tax liability, you'd eventually use the full credit; it just might take 2–3 years instead of one.

The question is whether your annual federal tax liability is large enough to make the credit meaningful in a reasonable timeframe. I don't know your tax situation, and I wouldn't want to guess — but here's a rough framework:

If a solar system costs $22,000 (a reasonable estimate for an 8kW system), the 30% ITC would be $6,600. If your annual federal tax liability is around $3,000–4,000, you'd use the credit in about two years. If it's $1,500–2,000, more like three to four years.

This is genuinely a question for your tax advisor or accountant, if you have one. They can look at your actual liability and tell you exactly how the credit would apply. I can explain how the credit works mechanically, but I'm not in a position to give you tax advice specific to your situation.

Would it be helpful to go through the other financial factors — net metering, electricity rate increases, payback period — so you have the full picture before talking to a tax advisor?

**User:** Yes let's do that. And yes I do have an accountant so I can check with her about the tax credit specifics

---

## Session 4 — March 8, 2026

**User:** I talked to my accountant and she says the tax credit would work for me, it would just take two years to fully use it. So that's good, Now I want to understand the payback period. How long until the panels actually save me more than they cost

**Assistant:** Good — two years for the full credit is very workable.

Payback period is the point where your cumulative electricity savings equal what you paid for the system (after incentives). Here's how to think about it:

**Estimated system cost:** For an 8kW system in North Carolina, installed costs typically run $2.75–$3.50 per watt, so roughly $22,000–$28,000. Let's use $24,000 as a middle estimate.

**After the 30% ITC:** $24,000 × 0.70 = $16,800 net cost.

**Annual electricity savings:** If the system produces about 11,000 kWh per year (reasonable for 8kW in NC with your roof conditions) and Duke Energy charges around $0.12–0.13 per kWh, your annual savings would be roughly $1,300–$1,400.

**Simple payback:** $16,800 ÷ $1,350 ≈ **12–13 years.**

**But there's an important factor:** electricity rates almost always increase over time. Duke Energy's rates have risen about 2–3% per year historically. If that trend continues, your savings grow each year because you're avoiding increasingly expensive electricity. That shortens the effective payback to more like 10–11 years.

**After payback:** The panels keep producing for another 15–20 years with minimal maintenance. That's 15–20 years of essentially free electricity.

A few caveats on these numbers:
- Actual quotes will give you specific production estimates modeled on your roof
- Panel degradation (output decreases about 0.5% per year) is a real factor but small
- Net metering policies can change, which would affect the value of excess generation
- These are estimates — your actual costs and savings will depend on the specific quotes you get

Does the payback timeline feel reasonable to you, or is that longer than you were expecting?

**User:** It's about what I expected honestly. I'm planning to stay in this house so the long timeline is fine. The panels would also add value to the house if I ever did sell

**Assistant:** That's a fair point about resale value. Studies have shown that solar panels do increase home value — the most commonly cited research suggests an increase of roughly $15,000–$20,000 for an average residential system, though this varies by market. In practice, it means you're likely to recover a significant portion of your investment even if you sell before the full payback period.

One thing I want to flag since you mentioned staying long-term: panel warranties are typically 25 years for production and 10–12 years for equipment. The inverter warranty is the one to watch — string inverters usually carry a 10–12 year warranty and may need replacement once during the life of the panels ($1,000–2,000). Microinverters typically have 25-year warranties that match the panels. This is worth factoring into your cost comparison when you get quotes.

Are you ready to start thinking about getting quotes from installers, or are there other aspects of the research you want to cover first?

---

## Session 5 — March 14, 2026

**User:** I think I'm almost ready for quotes. But one more thing -- I keep seeing ads for Tesla Solar and then local companies. Is there a meaningful difference between going with a big national company vs a local installer. Also wanted to ask — my neighbor got solar last year and he said something about his system having a battery. Is that something I should be looking at?

**Assistant:** Let me address the battery question first, and then the national vs. local installer question.

**Solar batteries (home battery storage):**

A battery stores excess solar energy produced during the day so you can use it at night or during a power outage. The most common residential battery is the Tesla Powerwall, but there are several competitors (Enphase, LG, Generac, Franklin).

Whether a battery makes sense depends on a few things:

1. **Power outage concerns.** If your area loses power frequently (storms, grid issues), a battery provides backup power. Without a battery, your solar system actually shuts down during a grid outage for safety reasons — the panels can't power your house independently.

2. **Net metering value.** With Duke Energy's current net metering, excess power you generate during the day earns you credits on your bill. If the credits are valued at the full retail rate, a battery doesn't save you much extra — you're effectively using the grid as free storage. If the credits are at a lower rate (some utilities are moving this direction), a battery becomes more financially valuable.

3. **Cost.** A home battery typically adds $10,000–15,000 to the system cost. The 30% federal tax credit applies to batteries installed with solar, which helps, but the payback on the battery alone is usually longer than the payback on the panels.

I don't know whether your area has frequent outages or whether backup power is a priority for you. If power reliability is a concern, a battery is worth pricing out. If your power is generally reliable and your main goal is reducing your electric bill, the battery may not be cost-effective right now — battery prices are still dropping, so adding one in a few years might make more financial sense.

Would you like to discuss this further, or should I move to the national vs. local installer question?

**User:** Th e power goes out maybe once or twice a year here for a few hours. Not a big deal usually. I think I'll skip the battery for now and maybe revisit it later like you said. Go ahead on the installer question

**Assistant:** That sounds like a reasonable call. On to installers:

**National companies (Tesla, Sunrun, SunPower, etc.):**
- Standardized products and processes
- Brand recognition, which some people find reassuring
- Often use subcontractors for installation rather than their own crews
- Can be harder to reach for service issues — you're dealing with a call center
- Pricing is sometimes higher because of marketing and overhead costs
- Tesla in particular has a reputation for lower prices but longer wait times and inconsistent communication

**Local/regional installers:**
- Usually install with their own crews, so the people who designed your system are the ones on your roof
- More accessible for service, questions, and warranty issues — you can call or visit the office
- Often more flexible on equipment choices (national companies may lock you into their own brand)
- Quality varies more — some local installers are excellent, some are not
- Check reviews, ask for references, and verify they're licensed and insured

**How to evaluate any installer:**
- Are they NABCEP-certified? (North American Board of Certified Energy Practitioners — the industry credential)
- How long have they been in business?
- Will they handle the permitting and utility interconnection paperwork?
- What equipment brands do they use?
- What does their warranty cover — workmanship, equipment, and production guarantee?
- Can they provide references from installations they've done in your area?

I don't have a blanket recommendation for national vs. local, because it really depends on the specific companies available in your area. The best approach is probably to get quotes from two or three different companies — ideally at least one local and one national — and compare not just price but equipment, warranties, production estimates, and how responsive they are during the quote process.

Would it be helpful to talk about what to look for in a quote, so you know how to compare them apples-to-apples?

**User:** Yes, that would be helpful. I want to know what to compare so I don't just go with whoever has the lowest number

---

## Session 6 — March 20, 2026

**User:** I have three quotes now. Two from local companies and one from Tesla. The numbers are pretty different and I'm not sure how to compare them. Can I share the details with you?

**Assistant:** Absolutely — go ahead and share whatever details you're comfortable with, and I'll help you break down the comparison. The key things I'd want to see for each quote are:

- System size (kW)
- Panel brand and model
- Inverter type (string vs. microinverter) and brand
- Total cost before incentives
- Estimated annual production (kWh)
- Warranty terms (panels, inverter, workmanship)
- Whether permitting and interconnection are included

If any of those are missing from a quote, that's itself useful information — a complete, transparent quote is a good sign.

**User:** OK here goes. Company A (local): 8.4 kW system, REC panels, Enphase microinverters, $26,800 before tax credit. They estimate 11,500 kWh/year. 25 year panel warranty, 25 year microinverter warranty, 10 year workmanship. Permitting and interconnection included
Company B (local): 7.8 kW system, Canadian Solar panels, SolarEdge string inverter with optimizers, $22,400 before tax credit. They estimate 10,800 kWh/year. 25 year panel warranty, 12 year inverter warranty, 5 year workmanship. Permitting included, not sure about interconnection
Tesla: 8.16 kW system, Tesla panels, Tesla string inverter, $19,900 before tax credit. They estimate 10,600 kWh/year. 25 year panel warranty, 12.5 year inverter warranty, 10 year workmanship. Everything included

**Assistant:** This is a useful set of quotes because they're different enough to illustrate the trade-offs. Let me break it down:

**Cost per watt (a standard way to compare):**
- Company A: $26,800 ÷ 8,400W = $3.19/watt
- Company B: $22,400 ÷ 7,800W = $2.87/watt
- Tesla: $19,900 ÷ 8,160W = $2.44/watt

Tesla is significantly cheaper per watt. That's consistent with their general pricing strategy — they price aggressively. The question is what you're getting for the lower price.

**Equipment quality:**
- Company A's REC panels and Enphase microinverters are premium, well-regarded equipment. Enphase microinverters carry 25-year warranties and are considered the industry standard for microinverters.
- Company B's Canadian Solar panels are mid-tier — solid and reliable. The SolarEdge inverter with power optimizers is a hybrid approach (string inverter with panel-level optimization). Good equipment, 12-year inverter warranty.
- Tesla uses their own panels and inverter. Quality is acceptable but generally not considered top-tier. The inverter is the least proven of the three options.

**Production estimates:**
- Company A: 11,500 kWh from 8.4kW = 1,369 kWh per kW
- Company B: 10,800 kWh from 7.8kW = 1,385 kWh per kW
- Tesla: 10,600 kWh from 8.16kW = 1,299 kWh per kW

Companies A and B are estimating similar production per kW. Tesla's estimate is lower per kW, which might reflect different assumptions or less optimized panel placement modeling.

**Warranties — the key differentiator:**
- Company A: 25-year everything on equipment, 10-year workmanship. This is strong.
- Company B: 25-year panels, but only 12-year inverter and 5-year workmanship. The inverter will likely need replacement in year 12–15 (at your cost, probably $1,500–2,500). The 5-year workmanship warranty is short — if there's a roof leak from the installation, you want that covered longer.
- Tesla: 12.5-year inverter warranty, same concern as Company B about eventual replacement. 10-year workmanship is better than Company B.

**What I'd want to clarify before choosing:**
- Company B: Is interconnection included? If not, what's the cost? And can they match the 10-year workmanship warranty?
- Tesla: What's the timeline? Tesla installations in some areas have significant delays.
- Company A: Their price is highest, but they're also offering the most robust equipment and warranty. Can you ask whether they have any flexibility on pricing?

I'm not going to tell you which one to pick, because it depends on what you value — lowest upfront cost, best equipment, longest warranty coverage, or some balance. But I'd say Company A's quote is the most complete and transparent, Company B needs some clarification, and Tesla's low price comes with trade-offs in equipment quality and inverter warranty.

What's your reaction to this breakdown?

**User:** This is really helpful. I think Company A is looking like the strongest option but I want to ask them about price. And I'll ask Company B about the interconnection and warranty. Thank you for walking through all of this so carefully

**Assistant:** You're welcome. Those are the right follow-up questions. When you hear back from Companies A and B, feel free to share what they say and I can help you evaluate the updated picture.

One last thing to keep in mind during the final decision: ask each company about their installation timeline and what the process looks like after you sign — permitting, inspection, utility approval, and activation. In some areas, the time from signing to actually generating power can be 2–4 months. Knowing the timeline upfront helps you plan.

Good luck with the follow-up conversations.

---

## Session 7 — March 28, 2026

**User:** Quick update. Company A came down to $24,500 when I asked, and Company B clarified that interconnection is included and they'll extend workmanship to 10 years. So the comparison is closer now. I think I'm going with Company A though — the Enphase microinverters and the overall quality of their quote give me more confidence. Signing with them next week

**Assistant:** That sounds like a well-reasoned decision. You did the research, compared real quotes on the relevant dimensions, and you're going with the option that gives you the strongest equipment and warranty coverage at a price that came down to a more competitive range. The Enphase microinverters in particular are a good long-term choice — the 25-year warranty means you're unlikely to face any inverter replacement costs during the life of the system.

When you sign, a few things to confirm in the contract:
- The exact equipment specified (REC panels, Enphase microinverters — make sure models are listed)
- The production estimate and whether there's any production guarantee
- The warranty terms in writing
- The installation timeline with key milestones
- Who handles permitting, inspection, and Duke Energy interconnection
- Payment schedule (when payments are due relative to milestones)

If anything in the contract is unclear or different from what was discussed in the quote, ask before signing. And congratulations — you've done this the right way.

**User:** Thank you!! I feel good about it. I'll probably have more questions once installation starts but for now I think I have what I need

**Assistant:** Sounds good. Come back anytime during the installation process if questions come up — whether it's about what the crew is doing on the roof, how the electrical work connects, or what to expect from the Duke Energy interconnection process. Happy to help at whatever stage.
